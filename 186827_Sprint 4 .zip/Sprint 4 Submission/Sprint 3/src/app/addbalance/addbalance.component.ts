import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { ConnectService } from '../../data/connect.service';



@Component({
  selector: 'app-addbalance',
  templateUrl: './addbalance.component.html',
  styleUrls: ['./addbalance.component.css']
})
export class AddbalanceComponent implements OnInit {
  array=[]
  user: any
  flag=false
  successflag=false
    constructor(private service: ConnectService) { }
  
    ngOnInit() {
    }
  
    find(number){
      this.service.findbyid(number).subscribe(data=> {this.array=data})
      this.flag=true    
    }
    update(number, amount){
      this.service.update(number,amount).subscribe(data=>{this.array=data})
      this.successflag=true
    }
}
