import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { ConnectService } from '../../data/connect.service';
@Component({
  selector: 'app-showall',
  templateUrl: './showall.component.html',
  styleUrls: ['./showall.component.css']
})
export class ShowallComponent implements OnInit {
  array:any
  
  
  constructor(private service: ConnectService) {
    
   }

   
  ngOnInit() {
    this.service.viewAll().subscribe(data=>{this.array=data});
  }

}
