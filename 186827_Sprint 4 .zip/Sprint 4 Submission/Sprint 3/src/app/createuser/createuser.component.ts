import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { ConnectService } from '../../data/connect.service';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.css']
})
export class CreateuserComponent implements OnInit {
  array: any
  accNum: number;
  successflag = false
  user: any
  constructor(private service: ConnectService) { }

  ngOnInit() {
  }

  add(form) {

    this.user={
      name: form.name,
      phoneNumber: form.phone,
      emailId: form.email,
      balance: 0
    }
    this.service.create(this.user).subscribe(data=> {this.array=data})
    this.successflag = true;
  }
}
