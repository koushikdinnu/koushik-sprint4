package com.capgemini.bankWallet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankWallet.exceptions.AccountException;
import com.capgemini.bankWallet.model.Account;
import com.capgemini.bankWallet.service.AccountService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AccountController {
	@Autowired
	AccountService service;
	
	@GetMapping(value="/viewall")
	public List<Account> viewAll() throws AccountException
	{
		return service.getAllAccounts();
	}
	
	@PostMapping("/create")
	public List<Account> create(@RequestBody Account user) throws Exception
	{
		return service.createAccount(user);
	}
	
	@GetMapping("/viewbyid/{id}")
	public List<Account> viewById(@PathVariable int id) throws Exception
	{
		return service.viewAccount(id);
	}
	@GetMapping("/viewaccounts/{id1}/{id2}")
	public List<Account> viewaccounts(@PathVariable int id1,@PathVariable int id2) throws Exception
	{
		return service.viewAccounts(id1,id2);
	}
	
	@PutMapping("/addmoney/{id}")
	public List<Account> addMoney(@PathVariable int id,@RequestParam(value="number") Integer amount) throws Exception
	{
		return service.addMoney(id, amount);
	}
	
	@PutMapping("/transfer/{id1}/{id2}")
	public List<Account> transfer(@PathVariable int id1, @PathVariable int id2, @RequestParam(value="number") Integer amount) throws Exception
	{
		return service.transfer(id1, id2, amount);
	}
	
}
