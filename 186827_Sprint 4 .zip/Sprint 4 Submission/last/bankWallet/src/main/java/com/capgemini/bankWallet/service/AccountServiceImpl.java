package com.capgemini.bankWallet.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bankWallet.dao.AccountDao;
import com.capgemini.bankWallet.exceptions.AccountException;
import com.capgemini.bankWallet.model.Account;

@Service
public class AccountServiceImpl implements AccountService{
	@Autowired
	AccountDao dao;
	
	Validator validate=new Validator();

	@Override
	public List<Account> createAccount(Account user) throws AccountException {
		// TODO Auto-generated method stub
		try
		{
			validate.validator(user);
			dao.save(user);
			List<Account> list=new ArrayList<Account>();
			list.add(user);
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> viewAccount(int accountNumber) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			Optional<Account> user=dao.findById(accountNumber);
			List<Account> list=new ArrayList<Account>();
			list.add(user.get());
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> addMoney(int accountNumber, int amount) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			validAccountNumber(accountNumber);
			Optional<Account> op=dao.findById(accountNumber);
			Account user=op.get();
			user.setBalance(user.getBalance()+amount);
			dao.save(user);
			List<Account> list=new ArrayList<Account>();
			list.add(user);
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> transfer(int accountNumber1, int accountNumber2, int amount) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			List<Account> list= new ArrayList<Account>();
			validAccountNumber(accountNumber1);
			validAccountNumber(accountNumber2);
			if(accountNumber1==accountNumber2)
			{
				throw new AccountException("The given Accounts are same");
			}
			else
			{
				Optional<Account> op=dao.findById(accountNumber1);
				Account user1=op.get();
				if(user1.getBalance()>=amount)
				{
					op=dao.findById(accountNumber2);
					Account user2=op.get();
					user1.setBalance(user1.getBalance()-amount);
					user2.setBalance(user2.getBalance()+amount);
					dao.save(user1);
					dao.save(user2);
					list.add(user1);
					list.add(user2);
				}
				else
				{
					throw new AccountException("Insuffecient balance in sender account");
				}
			}
			return list;			
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> getAllAccounts() throws AccountException {
		// TODO Auto-generated method stub
		try
		{
			return dao.findAll();
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}
	
	public void validAccountNumber(int accountNumber) throws AccountException
	{
		try
		{
			Optional<Account> user=dao.findById(accountNumber);
			if(!user.isPresent())
			{
				throw new AccountException("Account:"+accountNumber+" Not Found");
			}
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> viewAccounts(int id1, int id2) throws AccountException {
		// TODO Auto-generated method stub
		try
		{
			Optional<Account> user=dao.findById(id1);
			List<Account> list=new ArrayList<Account>();
			list.add(user.get());
			user=dao.findById(id2);
			list.add(user.get());
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}
}
