package com.capgemini.bankWallet.service;

import java.util.List;

import com.capgemini.bankWallet.exceptions.AccountException;
import com.capgemini.bankWallet.model.Account;

public interface AccountService {
	public List<Account> createAccount(Account user) throws AccountException;
	public List<Account> viewAccount(int accountNumber) throws Exception;
	public List<Account> addMoney(int accountNumber, int amount) throws Exception;
	public List<Account> transfer(int accountNumber1,int accountNumber2, int amount) throws Exception;
	public List<Account> getAllAccounts() throws AccountException;
	public List<Account> viewAccounts(int id1, int id2) throws AccountException;
}
